<template>
	<view class="content">
		<h1>柱状图测试</h1>
		<view style="width: 100%; height:500rpx"><l-f2 ref="base"></l-f2></view>
		<br><br>
		<view style="width: 100%; height:500rpx"><l-f2 ref="base2"></l-f2></view>
	</view>
</template>

<script>
	import F2 from '@/components/lime-f2/f2.min.js';
	import lF2 from '@/components/lime-f2/'
	
	export default {
	    components: {lF2},
	    data() {
	        return {
	            baseData: [{ genre: '成犬粮', sold: 275 }, { genre: '化毛膏', sold: 115 }, { genre: '益生菌', sold: 120 }, { genre: '氨糖', sold: 350 }, { genre: '其它', sold: 150 }],
				baseData2: [{ genre: '测试1', sold: 100 }, { genre: '测试2', sold: 210 }, { genre: '测试3', sold: 350 }]
			}
	    },
		methods: {
			buttest(baseValue, baseDataValue) {
				const base = baseValue;
				base.init(config => {
				    const chart = new F2.Chart(config);
				    chart.source(baseDataValue);
				    chart.interval().position('genre*sold').color('genre');
				    chart.render();
				    // 需要把 chart 返回
				    return chart;
				});
			}
		},
	    mounted() {
			this.buttest(this.$refs.base, this.baseData)
			this.buttest(this.$refs.base2, this.baseData2)
	    }
	}
</script>

<style>
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.logo {
		height: 200rpx;
		width: 200rpx;
		margin-top: 200rpx;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 50rpx;
	}

	.text-area {
		display: flex;
		justify-content: center;
	}

	.title {
		font-size: 36rpx;
		color: #8f8f94;
	}
</style>
