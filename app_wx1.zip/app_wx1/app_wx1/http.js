import Vue from 'vue'
import axios from 'axios'
 

// 在main.js中放入这段自定义适配器的代码，就可以实现uniapp的app和小程序开发中能使用axios进行跨域网络请求，并支持携带cookie
axios.defaults.adapter = function(config) {
	return new Promise((resolve, reject) => {
		console.log('===== 777 ====' + JSON.stringify(config))
		var settle = require('axios/lib/core/settle');
		var buildURL = require('axios/lib/helpers/buildURL');
		uni.request({
			method: config.method.toUpperCase(),
			url: config.url,
			header: config.headers,
			data: config.data,
			dataType: config.dataType,
			responseType: config.responseType,
			sslVerify: config.sslVerify,
			complete: function complete(response) {
				console.log("执行完成：", response)
				response = {
					data: response.data,
					status: response.statusCode,
					errMsg: response.errMsg,
					header: response.header,
					config: config
				};
 
				settle(resolve, reject, response);
			}
		})
	})
}

// 请求的时候做拦截
axios.interceptors.request.use((confirm) => {
	console.log('index1 ======= loading')   // 请求的时候loading
	return confirm;
})
// 响应的时候做拦截
axios.interceptors.response.use((confirm) => {
	console.log('index1 ======= loading end') 
	return confirm;
})
